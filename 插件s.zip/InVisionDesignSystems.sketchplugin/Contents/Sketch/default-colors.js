/* eslint-disable */ const DEFAULT_COLORS = {
  "name": "Default",
  "_id": "default",
  "colors": [
    {
      "name": "Black",
      "value": "#000000",
      "_id": "black"
    },
    {
      "name": "Gray",
      "value": "#B8B8B8",
      "_id": "gray"
    },
    {
      "name": "White",
      "value": "#ffffff",
      "_id": "white"
    }
  ]
};
