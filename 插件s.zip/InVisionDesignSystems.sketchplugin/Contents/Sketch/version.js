/* eslint-disable */
const VERSION = 'v1.0.5';
